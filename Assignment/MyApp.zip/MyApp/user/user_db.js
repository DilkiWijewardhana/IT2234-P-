let users = [
    { id: '1', username: 'john', email: 'john@example.com', fullName: 'John Doe' },
    { id: '2', username: 'alice', email: 'alice@example.com', fullName: 'Alice Smith' },
    { id: '3', username: 'bob', email: 'bob@example.com', fullName: 'Bob Jackson' },
    { id: '4', username: 'emma', email: 'emma@example.com', fullName: 'Emma Jones' },
    { id: '5', username: 'mike', email: 'mike@example.com', fullName: 'Mike Brown' }
];

module.exports = users;