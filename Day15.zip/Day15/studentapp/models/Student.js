const mongoose = require('mongoose')
const studentSchema = new mongoose.Schema({
    regNo: {type:String, require:true},
    name:{type:String, require: true},
    age: {type:Number, require: true},
    courseCode: {type:String, require: true},
    degreeID: {
        type:String,
        require:true,
        ref:'degrees'
    },
    enrolled_courses:[{
        type:mongoose.Types.ObjectId,
        ref:'courses'
    }]
})

const Student = mongoose.model('students', studentSchema)
const student1 = new Student({
    regNo: "2021ICT60",
    name: "Dilki",
    age: 23,
    courseCode: "IT2234",
    degreeID: "FAS2021ICT",
    enrolled_courses:['682ebec8c9e26d8dc52414cf', '682ec23112d353a5d6ee6247']
})
student1.save()
module.exports=Student