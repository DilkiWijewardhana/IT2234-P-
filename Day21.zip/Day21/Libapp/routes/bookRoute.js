const express = require('express');
const router = express.Router();
const Book = require('../models/Book');
const service = require('../service/commonService');
const { verifyToken } = require('../middleware/auth');
//const { verifyToken } = require('jsonwebtoken');

router.get('/', verifyToken, async(req, res) => {
    service.findFun(res,Book)
})

router.get('/genre/:genreName', verifyToken, async(req, res) => {
    const genre = req.params.genreName;
    service.filterFun(res,Book,{genre:genre});
})


module.exports= router ;
