const mongoose=require('mongoose')
const studentSchema = new mongoose.Schema({
    id:{type:String,require:true},
    name:{type:String,require:true},
    date_of_birth:{type:Date},
    gender:{type:String},
    degreeID:{
        type:String,
        require:true,
        ref:'degrees'
    },
    enroled_courses:[{type:mongoose.Types.ObjectId,ref:'course'}]
})

const Student = mongoose.model('students',studentSchema)
const Kolins = new Student({
    id:'2021ICT01',
    name:'Peter Kolins',
    date_of_birth:'01-05-1997',
    gender:'male',
    degreeID:'FAS2000ICT',
    enroled_course:
})
Kolins.save()
module.exports=Student 